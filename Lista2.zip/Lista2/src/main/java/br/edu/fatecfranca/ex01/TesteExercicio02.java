package br.edu.fatecfranca.ex01;

public class TesteExercicio02 {

    public static void main(String[] args) {
        Exercicio02 fatec = new Exercicio02 ();
        fatec.setNaluno (111111);
        fatec.setNome ("Alexandre");
        fatec.setIdade (25);
        fatec.setP1 (10);
        fatec.setP2 (5);
        fatec.notaFinal ();
        fatec.dadosAluno();
        
    }
    
}
